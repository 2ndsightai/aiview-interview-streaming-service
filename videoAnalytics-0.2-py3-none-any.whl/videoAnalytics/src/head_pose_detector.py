import cv2
import pickle
import pandas as pd
from .head_pose_utils import HeadPoseUtils
import pkg_resources

class HeadPoseDetector:
    def __init__(self):
        model_path = model_path = pkg_resources.resource_filename(__name__, 'model.pkl')
        self.model = pickle.load(open(model_path, 'rb'))
        self.headPoseUtils = HeadPoseUtils()
        self.cols = []
        self.landmark_pts = ['nose_', 'forehead_', 'left_eye_', 'mouth_left_', 'chin_', 'right_eye_', 'mouth_right_']
        for pos in self.landmark_pts:
            for dim in ('x', 'y'):
                self.cols.append(pos+dim)
        
    
    def detect_distraction(self, image):
        img = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        landmark_list, face_features_list, _, _ = self.headPoseUtils.extract_features(img)

        for idx, face_features in enumerate(face_features_list):
            if len(face_features):
                face_features_df = pd.DataFrame([face_features], columns=self.cols)
                face_features_normalized = self.headPoseUtils.normalize(face_features_df)
                pitch_pred, yaw_pred, roll_pred = self.model.predict(face_features_normalized).ravel()

                if pitch_pred > 0.3 or pitch_pred < -0.3 or abs(yaw_pred) > 0.3:
                    return True
        return False
    
    def get_features(self, image):
        img = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        landmark_list, face_features_list, eye_blink_ratio_list, eye_position_list = self.headPoseUtils.extract_features(img)
        face_features_df = pd.DataFrame([face_features_list[0]], columns=self.cols)
        face_features_normalized = self.headPoseUtils.normalize(face_features_df)
        pitch_pred, yaw_pred, roll_pred = self.model.predict(face_features_normalized).ravel()
        return landmark_list[0], eye_blink_ratio_list[0], eye_position_list[0],  pitch_pred, yaw_pred, roll_pred