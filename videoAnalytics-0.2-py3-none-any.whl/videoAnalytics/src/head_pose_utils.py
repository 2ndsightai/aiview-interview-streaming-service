import cv2
import mediapipe as mp
import numpy as np
import math

class HeadPoseUtils:
    def __init__(self):
        self.max_num_faces = 1
        self.face_mesh = mp.solutions.face_mesh.FaceMesh(static_image_mode=True, max_num_faces=self.max_num_faces, min_detection_confidence=0.5, min_tracking_confidence=0.5)

    
    def extract_features(self, img):
        NOSE = 1
        FOREHEAD = 10
        LEFT_EYE = 33
        MOUTH_LEFT = 61
        CHIN = 199
        RIGHT_EYE = 249
        MOUTH_RIGHT = 291

        # Left eyes indices 
        RIGHT_EYE_ROI =[ 362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385,384, 398 ]
        RIGHT_EYEBROW =[ 336, 296, 334, 293, 300, 276, 283, 282, 295, 285 ]

        # right eyes indices
        LEFT_EYE_ROI =[ 33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161 , 246 ]  
        LEFT_EYEBROW =[ 70, 63, 105, 66, 107, 55, 65, 52, 53, 46 ]

        # Blinking Detection landmark's indices.
        # P0, P3, P4, P5, P8, P11, P12, P13
        LEFT_EYE_BD_POINTS = [33, 160, 159, 158, 133, 153, 145, 144]
        RIGHT_EYE_BD_POINTS = [362, 385, 386, 387, 263, 373, 374, 380]

        result = self.face_mesh.process(img)
        img_height, img_width, img_channel = img.shape
        # print(len(result.multi_face_landmarks))
        face_features = []
        face_features_list = []
        eye_blink_ratio_list = []
        eye_position = []
        landmark_list = []
        if result.multi_face_landmarks != None:
            for face_landmarks in result.multi_face_landmarks:
                face_features = []
                mesh_coord = [(int(point.x * img_width), int(point.y * img_height)) for point in face_landmarks.landmark]
                landmark_list.append(mesh_coord)
                for idx, lm in enumerate(face_landmarks.landmark):
                    if idx in [FOREHEAD, NOSE, MOUTH_LEFT, MOUTH_RIGHT, CHIN, LEFT_EYE, RIGHT_EYE]:
                        face_features.append(lm.x)
                        face_features.append(lm.y)

                mesh_points_3D = np.array(
                    [[n.x, n.y, n.z] for n in face_landmarks.landmark]
                )
                
                eyes_aspect_ratio = self.blinking_ratio_3D(mesh_points_3D, RIGHT_EYE_BD_POINTS, LEFT_EYE_BD_POINTS)

                # # Blink Detector Counter Completed
                right_coords = [mesh_coord[p] for p in RIGHT_EYE_ROI]
                left_coords = [mesh_coord[p] for p in LEFT_EYE_ROI]
                crop_right, crop_left = self.eyesExtractor(img, right_coords, left_coords)
                # # cv.imshow('right', crop_right)
                # # cv.imshow('left', crop_left)
                eye_position_right = self.positionEstimator(crop_right)
                eye_position_left = self.positionEstimator(crop_left)
                
                # # print(face_blink_ratio)
                face_features_list.append(face_features)
                eye_blink_ratio_list.append(eyes_aspect_ratio)
                eye_position.append((eye_position_left, eye_position_right))

        return landmark_list, face_features_list, eye_blink_ratio_list, eye_position

    # Euclaidean distance 
    def euclaideanDistance(self, point_1, point_2):
        x1, y1 = point_1
        x2, y2 = point_2
        distance = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        return distance

    # Eyes Extrctor function,
    def eyesExtractor(self, img, right_eye_coords, left_eye_coords):
        # converting color image to  scale image 
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        
        # getting the dimension of image 
        dim = gray.shape

        # creating mask from gray scale dim
        mask = np.zeros(dim, dtype=np.uint8)

        # # drawing Eyes Shape on mask with white color 
        cv2.fillPoly(mask, [np.array(right_eye_coords, dtype=np.int32)], 255)
        cv2.fillPoly(mask, [np.array(left_eye_coords, dtype=np.int32)], 255)

        # showing the mask 
        # cv.imshow('mask', mask)
        
        # draw eyes image on mask, where white shape is 
        eyes = cv2.bitwise_and(gray, gray, mask=mask)
        # change black color to gray other than eys 
        # cv.imshow('eyes draw', eyes)
        eyes[mask==0]=155
        
        # getting minium and maximum x and y  for right and left eyes 
        # For Right Eye 
        r_max_x = (max(right_eye_coords, key=lambda item: item[0]))[0]
        r_min_x = (min(right_eye_coords, key=lambda item: item[0]))[0]
        r_max_y = (max(right_eye_coords, key=lambda item : item[1]))[1]
        r_min_y = (min(right_eye_coords, key=lambda item: item[1]))[1]

        # For LEFT Eye
        l_max_x = (max(left_eye_coords, key=lambda item: item[0]))[0]
        l_min_x = (min(left_eye_coords, key=lambda item: item[0]))[0]
        l_max_y = (max(left_eye_coords, key=lambda item : item[1]))[1]
        l_min_y = (min(left_eye_coords, key=lambda item: item[1]))[1]

        # croping the eyes from mask 
        cropped_right = eyes[r_min_y: r_max_y, r_min_x: r_max_x]
        cropped_left = eyes[l_min_y: l_max_y, l_min_x: l_max_x]

        # returning the cropped eyes 
        return cropped_right, cropped_left

    # Blinking Ratio
    def blinkRatio(self, landmarks, right_indices, left_indices):
        # Right eyes 
        # horizontal line 
        rh_right = landmarks[right_indices[0]]
        rh_left = landmarks[right_indices[8]]
        # vertical line 
        rv_top = landmarks[right_indices[12]]
        rv_bottom = landmarks[right_indices[4]]
        # draw lines on right eyes 
        # cv.line(img, rh_right, rh_left, utils.GREEN, 2)
        # cv.line(img, rv_top, rv_bottom, utils.WHITE, 2)

        # LEFT_EYE 
        # horizontal line 
        lh_right = landmarks[left_indices[0]]
        lh_left = landmarks[left_indices[8]]

        # vertical line 
        lv_top = landmarks[left_indices[12]]
        lv_bottom = landmarks[left_indices[4]]

        rhDistance = self.euclaideanDistance(rh_right, rh_left)
        rvDistance = self.euclaideanDistance(rv_top, rv_bottom)

        lvDistance = self.euclaideanDistance(lv_top, lv_bottom)
        lhDistance = self.euclaideanDistance(lh_right, lh_left)

        reRatio = rhDistance/rvDistance
        leRatio = lhDistance/lvDistance

        ratio = (reRatio+leRatio)/2
        return ratio 

    def euclidean_distance_3D(self, points):
        """Calculates the Euclidean distance between two points in 3D space.

        Args:
            points: A list of 3D points.

        Returns:
            The Euclidean distance between the two points.

            # Comment: This function calculates the Euclidean distance between two points in 3D space.
        """

        # Get the three points.
        P0, P3, P4, P5, P8, P11, P12, P13 = points

        # Calculate the numerator.
        numerator = (
            np.linalg.norm(P3 - P13) ** 3
            + np.linalg.norm(P4 - P12) ** 3
            + np.linalg.norm(P5 - P11) ** 3
        )

        # Calculate the denominator.
        denominator = 3 * np.linalg.norm(P0 - P8) ** 3

        # Calculate the distance.
        distance = numerator / denominator

        return distance


    # This function calculates the blinking ratio of a person.
    def blinking_ratio_3D(self, landmarks, right_eye_points, left_eye_points):
        """Calculates the blinking ratio of a person.

        Args:
            landmarks: A facial landmarks in 3D normalized.

        Returns:
            The blinking ratio of the person, between 0 and 1, where 0 is fully open and 1 is fully closed.

        """

        # Get the right eye ratio.
        right_eye_ratio = self.euclidean_distance_3D(landmarks[right_eye_points])

        # Get the left eye ratio.
        left_eye_ratio = self.euclidean_distance_3D(landmarks[left_eye_points])

        # Calculate the blinking ratio.
        ratio = (right_eye_ratio + left_eye_ratio + 1) / 2

        return ratio

    def normalize(self, poses_df):
        normalized_df = poses_df.copy()
        
        for dim in ['x', 'y']:
            # Centerning around the nose 
            for feature in ['forehead_'+dim, 'nose_'+dim, 'mouth_left_'+dim, 'mouth_right_'+dim, 'left_eye_'+dim, 'chin_'+dim, 'right_eye_'+dim]:
                normalized_df[feature] = poses_df[feature] - poses_df['nose_'+dim]
            
            
            # Scaling
            diff = normalized_df['mouth_right_'+dim] - normalized_df['left_eye_'+dim]
            for feature in ['forehead_'+dim, 'nose_'+dim, 'mouth_left_'+dim, 'mouth_right_'+dim, 'left_eye_'+dim, 'chin_'+dim, 'right_eye_'+dim]:
                normalized_df[feature] = normalized_df[feature] / diff
        
        return normalized_df


    def draw_axes(img, pitch, yaw, roll, tx, ty, size=50):
        yaw = -yaw
        rotation_matrix = cv2.Rodrigues(np.array([pitch, yaw, roll]))[0].astype(np.float64)
        axes_points = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0]
        ], dtype=np.float64)
        axes_points = rotation_matrix @ axes_points
        axes_points = (axes_points[:2, :] * size).astype(int)
        axes_points[0, :] = axes_points[0, :] + tx
        axes_points[1, :] = axes_points[1, :] + ty
        
        new_img = img.copy()
        cv2.line(new_img, tuple(axes_points[:, 3].ravel()), tuple(axes_points[:, 0].ravel()), (255, 0, 0), 2)    
        cv2.line(new_img, tuple(axes_points[:, 3].ravel()), tuple(axes_points[:, 1].ravel()), (0, 255, 0), 2)    
        cv2.line(new_img, tuple(axes_points[:, 3].ravel()), tuple(axes_points[:, 2].ravel()), (0, 0, 255), 2)
        return new_img

    # Eyes Postion Estimator 
    def positionEstimator(self, cropped_eye):
        # getting height and width of eye 
        h, w =cropped_eye.shape
        
        # remove the noise from images
        gaussain_blur = cv2.GaussianBlur(cropped_eye, (9,9),0)
        median_blur = cv2.medianBlur(gaussain_blur, 3)

        # applying thrsholding to convert binary_image
        ret, threshed_eye = cv2.threshold(median_blur, 130, 255, cv2.THRESH_BINARY)

        # create fixd part for eye with 
        piece = int(w/3) 

        # slicing the eyes into three parts 
        right_piece = threshed_eye[0:h, 0:piece]
        center_piece = threshed_eye[0:h, piece: piece+piece]
        left_piece = threshed_eye[0:h, piece +piece:w]
        
        # calling pixel counter function
        eye_position = self.pixelCounter(right_piece, center_piece, left_piece)

        return eye_position 

    # creating pixel counter function 
    def pixelCounter(self, first_piece, second_piece, third_piece):
        # counting black pixel in each part 
        right_part = np.sum(first_piece==0)
        center_part = np.sum(second_piece==0)
        left_part = np.sum(third_piece==0)
        # creating list of these values
        eye_parts = [right_part, center_part, left_part]

        # getting the index of max values in the list 
        max_index = eye_parts.index(max(eye_parts))
        pos_eye ='' 
        if max_index==0:
            pos_eye="RIGHT"
        elif max_index==1:
            pos_eye = 'CENTER'
        elif max_index ==2:
            pos_eye = 'LEFT'
        else:
            pos_eye="CLOSED"
        return pos_eye




